import json
import globales
import random

productos = ["Cafe Americano","Te Chai","Croissant","Jugo Naranja","Panini de Pavo y Queso","Pastel de Zanahoria","Espresso Doble","Batido de Frutas","Muffin","Ensalada","Chocolate Caliente","Tarta de Frambuesa","Sandwich de Huevo","Galletas de Avena","Frappe de Caramelo"]

#Lo que faltó agregar
def redondear_a_centena(valor):
    return round(valor / 100) * 100

def generar_montos_aleatorios():
    items = []
    for producto in productos:
        #Corrección
        valor = random.randint(2000, 10000)
        valor = redondear_a_centena(valor)
        iva = int(valor*0.19)
        item = {
            "nombre": producto,
            "valor": valor,
            "iva": iva
        }
        items.append(item)
    globales.guardar_archivo_json('valores.json', items)

if __name__ == "__main__":
    generar_montos_aleatorios()