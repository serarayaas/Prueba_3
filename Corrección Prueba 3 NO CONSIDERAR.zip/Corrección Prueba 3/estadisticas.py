import json
import globales
import math

def calculo_estadistico():
    items = globales.leer_archivo_json('valores.json')
    if not items:
        print("No hay datos registrados")
        return
    
    valores = [item['valor'] for item in items]
    ivas = [item['iva'] for item in items]

    producto_valor_mas_alto = max(items, key=lambda x: x['valor'])
    producto_iva_mas_bajo = min(items, key=lambda x: x['iva'])
    promedio_valores = sum(valores) / len(valores)
    media_geometrica = math.exp(sum(math.log(valor) for valor in valores) / len(valores))

    print(f"Producto con el valor más alto: {producto_valor_mas_alto['nombre']}  ${producto_valor_mas_alto['valor']}")
    print(f"Producto con el valor del IVA más bajo: {producto_iva_mas_bajo['nombre']}  ${producto_iva_mas_bajo['iva']}")
    print(f"El promedio del valor de los productos es: ${promedio_valores:.2f}")
    print(f"La media geométrica del valor de los productos es: ${media_geometrica:.2f}")

if __name__ == "__main__":
    calculo_estadistico()
